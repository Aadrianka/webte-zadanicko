var menuItems = {
	"items": [
		{
			"name": "Domov",
			"class": "1",
			"href": "index.html",
			"children": null
		},
		{
			"name": "Text z článkov",
			"class": "1",
			"href": "clanky.html",
			"children": null
		},
		{
			"name": "Meniny",
			"class": "1",
			"href": "meniny.html",
			"children": null
		},
		{
			"name": "Tím",
			"class": "1",
			"href": null,
			"children": [
				{
					"name": "Jakub Matušov",
					"class": "2",
					"href": null,
					"children": [
						{
							"name": "Hra",
							"class": "3",
							"href":	"hra_matusov.html",
							"children": null
						},
						{
							"name": "Kontakt",
							"class": "3",
							"href":	"kontakt_matusov.html",
							"children": null
						}
					]
				},
				{
					"name": "Štefan Daňo",
					"class": "2",
					"href": null,
					"children": [
						{
							"name": "Hra",
							"class": "3",
							"href":	"hra_dano.html",
							"children": null
						},
						{
							"name": "Kontakt",
							"class": "3",
							"href":	"kontakt_dano.html",
							"children": null
						}
					]
				},
				{
					"name": "Adriána Selepová",
					"class": "2",
					"href": null,
					"children": [
						{
							"name": "Hra",
							"class": "3",
							"href":	"hra_selepova.html",
							"children": null
						},
						{
							"name": "Kontakt",
							"class": "3",
							"href":	"kontakt_dano.html",
							"children": null
						}
					]
				}
			]
		}
	]
	
}